<?php return array(
    'root' => array(
        'pretty_version' => 'dev-master',
        'version' => 'dev-master',
        'type' => 'library',
        'install_path' => __DIR__ . '/../',
        'aliases' => array(),
        'reference' => 'fa56c13484afa1baf908b93ed5b6990c6a0e9ad6',
        'name' => '__root__',
        'dev' => false,
    ),
    'versions' => array(
        '__root__' => array(
            'pretty_version' => 'dev-master',
            'version' => 'dev-master',
            'type' => 'library',
            'install_path' => __DIR__ . '/../',
            'aliases' => array(),
            'reference' => 'fa56c13484afa1baf908b93ed5b6990c6a0e9ad6',
            'dev_requirement' => false,
        ),
    ),
);
