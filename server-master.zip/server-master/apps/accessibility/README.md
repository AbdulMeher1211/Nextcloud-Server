# Accessibility ♿

> This app provide multiple features to ease the use of nextcloud.

## Build Setup

``` bash
# install dependencies
make dev-setup

# build for development
make build-js

# build for development and watch edits
make watch-js

# build for production with minification
make build-js-production

# clean output files
make clean
```
