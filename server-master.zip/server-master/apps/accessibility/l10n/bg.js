OC.L10N.register(
    "accessibility",
    {
    "Dark theme" : "Tъмна Tема",
    "Enable dark theme" : "Активиране на тъмна тема",
    "A dark theme to ease your eyes by reducing the overall luminosity and brightness. It is still under development, so please report any issues you may find." : "Тъмна тема, която облекчава очите ви, като намалява яркостта. Все още е в процес на разработка, затова, моля, докладвайте за всички проблеми, които откриете.",
    "High contrast mode" : "Висок контраст",
    "Enable high contrast mode" : "Активиране на режим с висок контраст",
    "A high contrast mode to ease your navigation. Visual quality will be reduced but clarity will be increased." : "Режим с висок контраст за улесняване на навигацията ви. Визуалното качество ще бъде намалено, но яснотата ще се увеличи.",
    "Dyslexia font" : "Шрифт за дислексия",
    "Enable dyslexia font" : "Активирай шрифт за дислексия",
    "OpenDyslexic is a free typeface/font designed to mitigate some of the common reading errors caused by dyslexia." : "OpenDyslexic е безплатен шрифт, предназначен за смекчаване на някои от често срещаните грешки при четенето, причинени от дислексия.",
    "Accessibility" : "Достъпност",
    "Accessibility options for nextcloud" : "Опции за достъпност за nextcloud",
    "Provides multiple accessibilities options to ease your use of Nextcloud" : "Осигурява множество опции за достъпност за улесняване на използването на Nextcloud",
    "Universal access is very important to us. We follow web standards and check to make everything usable also without mouse, and assistive software such as screenreaders. We aim to be compliant with the {guidelines}Web Content Accessibility Guidelines{linkend} 2.1 on AA level, with the high contrast theme even on AAA level." : "Универсалният достъп е много важен за нас. Следваме уеб стандартите и проверяваме, за да направим всичко използваемо и без мишка, и помощен софтуер, като екранни четци. Ние се стремим да бъдем съобразени с {guidelines}Насоки за достъпност на уеб съдържанието {linkend} 2.1 на ниво АА, с темата за висок контраст дори на ниво AAA.",
    "If you find any issues, don’t hesitate to report them on {issuetracker}our issue tracker{linkend}. And if you want to get involved, come join {designteam}our design team{linkend}!" : "Ако откриете някакви проблеми, не се колебайте да ги съобщите на {issueetracker} нашия тракер на проблеми {linkend}. А ако искате да се включите, елате да се присъедините {designteam} към нашия дизайнерски екип {linkend}!"
},
"nplurals=2; plural=(n != 1);");
