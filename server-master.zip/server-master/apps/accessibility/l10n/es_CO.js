OC.L10N.register(
    "accessibility",
    {
    "Dark theme" : "Tema oscuro",
    "Enable dark theme" : "Habilitar tema oscuro",
    "A dark theme to ease your eyes by reducing the overall luminosity and brightness. It is still under development, so please report any issues you may find." : "El tema oscuro se usa para aliviar sus ojos al reducir la luminosidad y el brillo general. Todavía está en desarrollo, así que informa cualquier problema que puedas encontrar.",
    "High contrast mode" : "Modo de alto contraste",
    "Enable high contrast mode" : "Habilitar alto contraste",
    "A high contrast mode to ease your navigation. Visual quality will be reduced but clarity will be increased." : "El modo de alto contraste se usa para facilitar la navegación. Se reducirá la calidad visual pero aumentará la claridad.",
    "Dyslexia font" : "Ayuda para disléxicos",
    "Enable dyslexia font" : "Habilitar ayuda para disléxicos",
    "OpenDyslexic is a free typeface/font designed to mitigate some of the common reading errors caused by dyslexia." : "OpenDislexic es una herramienta libre diseñada para mitigar algunos de los errores más comunes causados por la dislexia.",
    "Accessibility" : "Accesibilidad",
    "Accessibility options for nextcloud" : "Opciones de Accesibilidad para Nextcloud",
    "Provides multiple accessibilities options to ease your use of Nextcloud" : "Os da varias opciones de accesibilidad para facilitar su uso de Nextcloud",
    "Universal access is very important to us. We follow web standards and check to make everything usable also without mouse, and assistive software such as screenreaders. We aim to be compliant with the {guidelines}Web Content Accessibility Guidelines{linkend} 2.1 on AA level, with the high contrast theme even on AAA level." : "Acceso universal es muy importante para nosotros. Nosotros seguimos los estándares del internet y revisamos que todo este usable hasta sin ratón, y programas ayudantes como lectores de pantalla. Nosotros aspiramos de conformar con las {guidelines} Guías de Contenido Accesible del Web {linkend} 2.1 a nivel de AA y con un nivel de AAA con el tema de alto contraste. ",
    "If you find any issues, don’t hesitate to report them on {issuetracker}our issue tracker{linkend}. And if you want to get involved, come join {designteam}our design team{linkend}!" : "Si encuentras cualquier problema, no dudes de informarnos en {issuetracker} nuestro buscador de errores{linkend}, y si quieres involucrarse, únese {designteam} nuestro equipo de diseño  {{inkend} !"
},
"nplurals=2; plural=(n != 1);");
