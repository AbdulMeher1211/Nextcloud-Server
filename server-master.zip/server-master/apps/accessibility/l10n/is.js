OC.L10N.register(
    "accessibility",
    {
    "Dark theme" : "Dökkt þema",
    "Enable dark theme" : "Virkja dökkt þema",
    "A dark theme to ease your eyes by reducing the overall luminosity and brightness. It is still under development, so please report any issues you may find." : "Dökkt þema til að minnka álag á augun meðal annars með því að minnka heildarljósmagn og birtustig. Þetta er enn í þróun þannig að gott væri ef þú tilkynntir alla galla sem þú rekst á.",
    "High contrast mode" : "Mikil birtuskil",
    "Enable high contrast mode" : "Virkja ham með mikil birtuskil",
    "A high contrast mode to ease your navigation. Visual quality will be reduced but clarity will be increased." : "Þema með mikil birtuskil til að auðvelda vafur. Sjónræn gæði minnka en skýrleiki eykst",
    "Dyslexia font" : "Dyslexia letur",
    "Enable dyslexia font" : "Virkja letur fyrir lesblinda",
    "OpenDyslexic is a free typeface/font designed to mitigate some of the common reading errors caused by dyslexia." : "OpenDyslexic eru frjálsar leturgerðir sem eru hannaðar til að ráða bug á eða minnka vægi ýmissa villna sem stafa af lesblindu (dyslexia).",
    "Accessibility" : "Aukið aðgengi",
    "Accessibility options for nextcloud" : "Valkostir fyrir auðveldað aðgengi í Nextcloud",
    "Provides multiple accessibilities options to ease your use of Nextcloud" : "Býður upp á marga valkosti fyrir auðveldað aðgengi í Nextcloud",
    "Universal access is very important to us. We follow web standards and check to make everything usable also without mouse, and assistive software such as screenreaders. We aim to be compliant with the {guidelines}Web Content Accessibility Guidelines{linkend} 2.1 on AA level, with the high contrast theme even on AAA level." : "Aðgengi fyrir alla er okkur mikilvægt. Við fylgjum vefstöðlum oggöngum úr skugga um að allt sé nothæft án þess að nota tölvumús, auk þess að hjálpartæki á borð við skjálesara virki. Við miðum að samhæfni við {guidelines}Web Content Accessibility Guidelines{linkend} 2.1 á stigi AA, og höfum meira að segja háskerpuþemað miðað við stig AAA.",
    "If you find any issues, don’t hesitate to report them on {issuetracker}our issue tracker{linkend}. And if you want to get involved, come join {designteam}our design team{linkend}!" : "Ef þú rekst á einhver vandamál, ekki hika við að tilkynna þau á {issuetracker}verkbeiðnakerfinu okkar{linkend}. Og ef þig langar að taka þátt í þessu, gakktu þá til liðs við {designteam}hönnunarteymið okkar{linkend}!"
},
"nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);");
