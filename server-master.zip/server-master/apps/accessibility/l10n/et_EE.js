OC.L10N.register(
    "accessibility",
    {
    "Dark theme" : "Tume teema",
    "Enable dark theme" : "Luba tume teema",
    "High contrast mode" : "Kõrge kontrastsusega režiim",
    "Enable high contrast mode" : "Lubage kõrge kontrastsusega režiim.",
    "Dyslexia font" : "Düsleksia font",
    "Enable dyslexia font" : "Luba düsleksia font",
    "Accessibility" : "Ligipääsetavus"
},
"nplurals=2; plural=(n != 1);");
