OC.L10N.register(
    "accessibility",
    {
    "Dark theme" : "Tema escuro",
    "Enable dark theme" : "Enable dark theme",
    "A dark theme to ease your eyes by reducing the overall luminosity and brightness. It is still under development, so please report any issues you may find." : "Um tema escuro para aliviar os olhos, reduzindo a luminosidade e brilho geral. Ainda está em desenvolvimento, por isso, informe qualquer problema encontrado.",
    "High contrast mode" : "Modo de alto contraste",
    "Enable high contrast mode" : "Ativar modo de alto contraste",
    "A high contrast mode to ease your navigation. Visual quality will be reduced but clarity will be increased." : "O modo de alto contraste facilita a navegação. A qualidade visual será reduzida, mas a clareza será aumentada.",
    "Dyslexia font" : "Fonte de dislexia",
    "Enable dyslexia font" : "Ativar fonte dislexia",
    "OpenDyslexic is a free typeface/font designed to mitigate some of the common reading errors caused by dyslexia." : "OpenDyslexic é um tipo de letra/fonte grátis concebida para atenuar alguns dos erros comuns de leitura causados pela dislexia.",
    "Accessibility" : "Acessibilidade",
    "Accessibility options for nextcloud" : "Opções de acessibilidade para nextcloud",
    "Provides multiple accessibilities options to ease your use of Nextcloud" : "Fornece várias opções de acessibilidade para facilitar o uso do Nextcloud",
    "Universal access is very important to us. We follow web standards and check to make everything usable also without mouse, and assistive software such as screenreaders. We aim to be compliant with the {guidelines}Web Content Accessibility Guidelines{linkend} 2.1 on AA level, with the high contrast theme even on AAA level." : "O acesso universal é muito importante para nós. Seguimos os padrões da web e nos certificamos de tornar tudo utilizável também sem mouse e software auxiliar, como leitores de tela. Nosso objetivo é estar em conformidade com as {guidelines}Diretrizes de Acessibilidade para Conteúdo da Web{linkend} 2.1 no nível AA, com o tema de alto contraste, mesmo no nível AAA.",
    "If you find any issues, don’t hesitate to report them on {issuetracker}our issue tracker{linkend}. And if you want to get involved, come join {designteam}our design team{linkend}!" : "Se você encontrar algum problema, não hesite em reportá-lo no {issuetracker}nosso rastreador de problemas{linkend}. E se você quiser se envolver, junte-se à {designteam}nossa equipe de design{linkend}!"
},
"nplurals=2; plural=(n > 1);");
