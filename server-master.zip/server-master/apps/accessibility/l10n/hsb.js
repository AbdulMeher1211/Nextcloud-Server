OC.L10N.register(
    "accessibility",
    {
    "Dark theme" : "ćmowy moto",
    "Enable dark theme" : "ćmowy moto zmóžnić",
    "High contrast mode" : "modus z wulkim kontrastom",
    "Enable high contrast mode" : "modus z wulkim kontrastom zmóžnić",
    "Dyslexia font" : "pismo Dyslexia",
    "Enable dyslexia font" : "pismo Dyslexia zmóžnić",
    "Accessibility" : "přistupnosć",
    "Accessibility options for nextcloud" : "Móžnosće přistupa za nextcloud."
},
"nplurals=4; plural=(n%100==1 ? 0 : n%100==2 ? 1 : n%100==3 || n%100==4 ? 2 : 3);");
