OC.L10N.register(
    "comments",
    {
    "Cancel" : "Abbrechen",
    "Save" : "Speichern"
},
"nplurals=2; plural=(n != 1);");
