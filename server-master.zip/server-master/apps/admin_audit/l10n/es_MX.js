OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Auditoría / Registros",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Habilita las opciones de bitácora de Nextcloud tales como registro de acceso a archivos o de acciones delicadas."
},
"nplurals=2; plural=(n != 1);");
