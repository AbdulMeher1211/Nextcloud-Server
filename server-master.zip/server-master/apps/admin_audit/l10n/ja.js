OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "監査／ログ",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "アクセスやその他の不安定な動作のログファイルとして、Nextcloudに記録機能を提供します"
},
"nplurals=1; plural=0;");
