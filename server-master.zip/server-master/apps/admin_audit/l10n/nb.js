OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Gjennomgang / logger",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Gir Nextcloud loggegenskaper, som for eksempel å logge filtilganger eller på annet vis sensitive handlinger."
},
"nplurals=2; plural=(n != 1);");
