OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Auditoria / Registro",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Fornece recursos de registro para Nextcloud, como registros de acesso a arquivos ou outras ações confidenciais."
},
"nplurals=2; plural=(n > 1);");
