OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Auditoría / Registro",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Proporciona capacidades de registro para Nextcloud, como el acceso a archivos de registro o acciones sensibles."
},
"nplurals=2; plural=(n != 1);");
