OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "审计 / 日志",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "为 Nextcloud 提供日志能力，比如记录文件访问或其他敏感操作。"
},
"nplurals=1; plural=0;");
