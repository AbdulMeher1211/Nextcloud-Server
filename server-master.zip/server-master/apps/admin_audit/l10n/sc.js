OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Verìfica / Registratzione",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Frunit is diritos de registratzione pro Nextcloud comente is atzessos a documentos de registrazione o àteras atziones sensìbiles."
},
"nplurals=2; plural=(n != 1);");
