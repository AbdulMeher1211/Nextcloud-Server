OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Auditoria/registre",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Proporciona funcionalitats de registre per al Nextcloud, com ara un registre d'accés a fitxers o altres accions relacionades amb la confidencialitat."
},
"nplurals=2; plural=(n != 1);");
