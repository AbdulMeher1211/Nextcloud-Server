OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Auditování / zaznamenávání událostí",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Poskytuje Nextcloud schopnosti zaznamenávání událostí, jako například zaznamenávání přístupů k souborům nebo jiných citlivých akcí."
},
"nplurals=4; plural=(n == 1 && n % 1 == 0) ? 0 : (n >= 2 && n <= 4 && n % 1 == 0) ? 1: (n % 1 != 0 ) ? 2 : 3;");
