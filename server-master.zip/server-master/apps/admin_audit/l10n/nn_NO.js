OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Revisjon / Logging",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Tilbyr logg eigenskapar for Nextcloud, til dømes tilgang til loggfil eller andre følsame handlingar."
},
"nplurals=2; plural=(n != 1);");
