OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Auditoria / registo",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Fornece a funcionalidade de registo ao Nextcloud como o registo de acesso a ficheiros ou acções sensíveis."
},
"nplurals=2; plural=(n != 1);");
