OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Audit / journalisation",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Fournit des capacités de journalisation pour Nextcloud telles que l'accès aux fichiers de journalisation ou des actions autrement sensibles."
},
"nplurals=2; plural=(n > 1);");
