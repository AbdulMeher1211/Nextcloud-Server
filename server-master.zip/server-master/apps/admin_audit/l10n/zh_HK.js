OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "稽核 / 記錄",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "提供 Nextcloud 的記錄功能，例如記錄檔案存取或其他敏感操作。"
},
"nplurals=1; plural=0;");
