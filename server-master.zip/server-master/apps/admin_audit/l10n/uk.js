OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Аудит / журналювання",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Забезпечує можливості реєстрації для Nextcloud, такі як доступ до файлів журналу або інші дії, які є чутливими."
},
"nplurals=4; plural=(n % 1 == 0 && n % 10 == 1 && n % 100 != 11 ? 0 : n % 1 == 0 && n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 12 || n % 100 > 14) ? 1 : n % 1 == 0 && (n % 10 ==0 || (n % 10 >=5 && n % 10 <=9) || (n % 100 >=11 && n % 100 <=14 )) ? 2: 3);");
