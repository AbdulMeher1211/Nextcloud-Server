OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Auditing / Registrazione",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Fornisce capacità di registrazione per Nextcloud come la registrazione di accessi ai file o azioni altrimenti sensibili."
},
"nplurals=2; plural=(n != 1);");
