OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Έλεγχος/ Καταγραφή",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Παρέχει δυνατότητες καταγραφής για το Nextcloud όπως πρόσβαση σε αρχεία καταγραφής ή άλλες ευαίσθητες ενέργειες."
},
"nplurals=2; plural=(n != 1);");
