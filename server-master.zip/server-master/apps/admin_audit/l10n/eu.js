OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Auditoretza / Erregistroa",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Nextcloud-i  gaitasuna ematen dio, adibidez, fitxategien atzipenak edo bestelako ekintza babesgarriak erregistratzeko."
},
"nplurals=2; plural=(n != 1);");
