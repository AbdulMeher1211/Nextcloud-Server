OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Auditointi / lokitus",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Tarjoaa Nextcloudille lokin ylläpidon esimerkiksi tiedostojen käytöstä tai arkaluonteisista toiminnoista."
},
"nplurals=2; plural=(n != 1);");
