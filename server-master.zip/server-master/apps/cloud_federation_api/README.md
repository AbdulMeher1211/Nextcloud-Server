# cloud_federation_api
The cloud federation API allows to share information like files, contacts, calendars, incoming calls, etc accross Nextcloud instances
