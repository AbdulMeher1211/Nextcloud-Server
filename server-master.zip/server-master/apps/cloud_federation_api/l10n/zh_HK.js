OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "雲端聯盟 API",
    "Enable clouds to communicate with each other and exchange data" : "讓雲端可互相通訊並交換資料",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "雲端聯盟 API 讓多個 Nextcloud 站台可以互相通訊並交換資料。"
},
"nplurals=1; plural=0;");
