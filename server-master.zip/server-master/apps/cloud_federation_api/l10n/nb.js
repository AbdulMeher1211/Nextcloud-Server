OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "Cloud Federation API",
    "Enable clouds to communicate with each other and exchange data" : "Lar nettskyer kommunisere med hverandre og utveksle data.",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "Cloud Federation APIet lar flere instanser av Nextcloud kommunisere med hverandre og utveksle data."
},
"nplurals=2; plural=(n != 1);");
