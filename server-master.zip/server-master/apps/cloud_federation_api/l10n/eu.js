OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "Cloud Federation API",
    "Enable clouds to communicate with each other and exchange data" : "Aukera ematen du beste hodeirekin komunikatzeko eta datuak trukatzeko.",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "Cloud Federation APIk aukera ematen du hainbat Nextcloud instantzien artean elkarri komunikatzeko eta datuak trukatzeko. "
},
"nplurals=2; plural=(n != 1);");
