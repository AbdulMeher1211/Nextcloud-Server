OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "Federatzione Cloud API",
    "Enable clouds to communicate with each other and exchange data" : "Permite a is nues informàticas de comunicare a pares e iscambiare datos",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "Sa Federatzione Cloud API permitit a vàrias istàntzias de Nextocloud de comunicare a pares e iscambiare datos."
},
"nplurals=2; plural=(n != 1);");
