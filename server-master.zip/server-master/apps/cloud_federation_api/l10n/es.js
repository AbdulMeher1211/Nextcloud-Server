OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "Cloud Federation API",
    "Enable clouds to communicate with each other and exchange data" : "Permitir que las nubes se comuniquen entre ellas e intercambien datos",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "La API Cloud Federation permite que varias instancias de Nextcloud se comuniquen entre ellas e intercambien datos."
},
"nplurals=2; plural=(n != 1);");
