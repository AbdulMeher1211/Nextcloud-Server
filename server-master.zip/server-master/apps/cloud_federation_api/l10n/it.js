OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "API Federazione Cloud",
    "Enable clouds to communicate with each other and exchange data" : "Consenti ai cloud di comunicare tra loro e di scambiare dati",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "L'API Federazione Cloud consente a varie istanze di Nextcloud di comunicare tra loro e scambiare dati."
},
"nplurals=2; plural=(n != 1);");
