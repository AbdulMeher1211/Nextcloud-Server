OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "Cloud Federation API",
    "Enable clouds to communicate with each other and exchange data" : "Laat clouds met elkaar communiceren en gegevens uitwisselen",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "De Cloud Federation API stelt verschillende Nextcloud-servers in staat met elkaar te communiceren en gegevens uit te wisselen."
},
"nplurals=2; plural=(n != 1);");
