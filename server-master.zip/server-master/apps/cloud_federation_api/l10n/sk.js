OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "API združovania cloudu",
    "Enable clouds to communicate with each other and exchange data" : "Umožňuje cloudom navzájom komunikovať a vymieňať si údaje",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "API združovania cloudov umožňuje rôznym inštanciám NextCloudu navzájom komunikovať a vymieňať si údaje."
},
"nplurals=4; plural=(n % 1 == 0 && n == 1 ? 0 : n % 1 == 0 && n >= 2 && n <= 4 ? 1 : n % 1 != 0 ? 2: 3);");
